CREATE FUNCTION lpad (text, integer) RETURNS text
	LANGUAGE sql
AS $$
select pg_catalog.lpad($1, $2, ' ')
$$
