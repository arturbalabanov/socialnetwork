CREATE FUNCTION to_timestamp (double precision) RETURNS timestamp with time zone
	LANGUAGE sql
AS $$
select ('epoch'::pg_catalog.timestamptz + $1 * '1 second'::pg_catalog.interval)
$$
