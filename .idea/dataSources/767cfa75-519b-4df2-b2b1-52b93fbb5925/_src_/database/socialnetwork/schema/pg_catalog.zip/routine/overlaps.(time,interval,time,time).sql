CREATE FUNCTION overlaps (time without time zone, interval, time without time zone, time without time zone) RETURNS boolean
	LANGUAGE sql
AS $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$
